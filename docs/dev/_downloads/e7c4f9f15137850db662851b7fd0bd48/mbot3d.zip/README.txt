This is the source code for the 3D MiniBot on the CMUCAM website.
This code was written and run on a custom board we made using the
16F877 PIC chip.  It will, nevertheless, be useful and educational for
anyone hoping to program a chip to talk to CMUcam.

I have tried to include the key .h files (which, horribly, contain more than
just headers!).

The behavior of the 'bot is as follows:

When we turn on the PIC chip, the 'bot creeps forward. Then we turn on
CMUcam and the 'bot stops creeping and starts looking for the reddest thing
it can find, pitching and turning to center it.

enjoy,

Illah Nourbakhsh
The Robotics Institute
