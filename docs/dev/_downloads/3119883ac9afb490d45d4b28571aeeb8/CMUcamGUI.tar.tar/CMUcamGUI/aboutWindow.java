/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * This file is part of CMUcamGUI, a java program that helps     *
 * interface with the CMUcam Vision Board.                       *
 * Contact cmucam@cs.cmu.edu, or see                             *
 * http://www.cs.cmu.edu/~cmucam for more information.           *
 *                                                               *
 * Copyright 2001 Anthony Rowe                                   *
 *                                                               *
 * This program is free software; you can redistribute it and/or *
 * modify it under the terms of the GNU General Public License   *
 * as published by the Free Software Foundation - version 2.     *
 *                                                               *
 * This program is distributed in the hope that it will be       *
 * useful, but WITHOUT ANY WARRANTY; without even the implied    *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR       *
 * PURPOSE.  See the GNU General Public License in file COPYING  *
 * for more details.                                             *
 *                                                               *
 * You should have received a copy of the GNU General Public     *
 * License along with this program; if not, write to the Free    *
 * Software Foundation, Inc., 59 Temple Place - Suite 330,       *
 * Boston, MA 02111, USA.                                        *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.*;
import java.lang.Object;
import java.util.*;


public class aboutWindow extends Canvas
{
    Frame about_f;
    Panel about_p;
    Dialog about_d;
    
    aboutWindow()
    {
	about_f = new Frame();
	about_p= new Panel();
	

	TextArea about_t = new TextArea("This is CMUcamGUI v1.0, a java program that helps\ninterface with the CMUcam Vision Board.\nContact cmucam@cs.cmu.edu, or see\nhttp://www.cs.cmu.edu/~cmucam for more information.\n\nCopyright 2001 Anthony Rowe\n\nThis program is free software; you can redistribute it and/or\nmodify it under the terms of the GNU General Public License\nas published by the Free Software Foundation - version 2.\n\nThis program is distributed in the hope that it will be\nuseful, but WITHOUT ANY WARRANTY; without even the implied\nwarranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR\nPURPOSE.  See the GNU General Public License in file COPYING\nfor more details.\n\nYou should have received a copy of the GNU General Public\nLicense along with this program; if not, write to the Free\nSoftware Foundation, Inc., 59 Temple Place - Suite 330,\nBoston, MA 02111, USA.");

	Button about_b = new Button("Ok");
	about_b.addActionListener( new ActionListener() {
		public void actionPerformed(ActionEvent e)
		{
		    about_d.setVisible(false);
		}
	    } );
	about_d = new Dialog(about_f,"About CMUcamGUI");
	about_p.add("Center",about_t);
	about_p.add("South",about_b);
	about_d.add(about_p);
	about_d.setBounds(50,50,510,220);
	about_d.hide();
	
    }
    
    public void show()
    {
	about_d.setVisible(true);
    }
   

}
