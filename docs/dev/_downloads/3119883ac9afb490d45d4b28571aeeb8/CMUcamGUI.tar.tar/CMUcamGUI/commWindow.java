/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * This file is part of CMUcamGUI, a java program that helps     *
 * interface with the CMUcam Vision Board.                       *
 * Contact cmucam@cs.cmu.edu, or see                             *
 * http://www.cs.cmu.edu/~cmucam for more information.           *
 *                                                               *
 * Copyright 2001 Anthony Rowe                                   *
 *                                                               *
 * This program is free software; you can redistribute it and/or *
 * modify it under the terms of the GNU General Public License   *
 * as published by the Free Software Foundation - version 2.     *
 *                                                               *
 * This program is distributed in the hope that it will be       *
 * useful, but WITHOUT ANY WARRANTY; without even the implied    *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR       *
 * PURPOSE.  See the GNU General Public License in file COPYING  *
 * for more details.                                             *
 *                                                               *
 * You should have received a copy of the GNU General Public     *
 * License along with this program; if not, write to the Free    *
 * Software Foundation, Inc., 59 Temple Place - Suite 330,       *
 * Boston, MA 02111, USA.                                        *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.*;
import java.lang.Object;
import java.util.*;


public class commWindow extends Canvas
{
    Frame comm_f;
    Panel comm_p;
    TextField comm_t;
    Dialog comm_d;
    int done;

    commWindow()
    {
	done=0;
	comm_f = new Frame();
	comm_p= new Panel();
	comm_t = new TextField("/dev/ttyS0");
	Button comm_b = new Button("Ok");
	comm_b.addActionListener( new ActionListener() {
		public void actionPerformed(ActionEvent e)
		{
		    done=1;
		}
	    } );
	comm_d = new Dialog(comm_f,"Serial Port Select");
	comm_p.add(comm_t);
	comm_p.add(comm_b);
	comm_d.add(comm_p);
	comm_d.setBounds(50,50,180,70);
	comm_d.show();
	
    }
    

    public String getPort()
    {
	return comm_t.getText();
    }
    public int ready()
    {
	if(done==0) return 0;
	comm_d.setVisible(false);
	return 1;
    }
   
   

}
