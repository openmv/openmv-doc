/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * This file is part of CMUcamGUI, a java program that helps     *
 * interface with the CMUcam Vision Board.                       *
 * Contact cmucam@cs.cmu.edu, or see                             *
 * http://www.cs.cmu.edu/~cmucam for more information.           *
 *                                                               *
 * Copyright 2001 Anthony Rowe                                   *
 *                                                               *
 * This program is free software; you can redistribute it and/or *
 * modify it under the terms of the GNU General Public License   *
 * as published by the Free Software Foundation - version 2.     *
 *                                                               *
 * This program is distributed in the hope that it will be       *
 * useful, but WITHOUT ANY WARRANTY; without even the implied    *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR       *
 * PURPOSE.  See the GNU General Public License in file COPYING  *
 * for more details.                                             *
 *                                                               *
 * You should have received a copy of the GNU General Public     *
 * License along with this program; if not, write to the Free    *
 * Software Foundation, Inc., 59 Temple Place - Suite 330,       *
 * Boston, MA 02111, USA.                                        *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.*;
import java.lang.Object;
import java.util.*;


public class serialComm
{
    FileOutputStream sPortOut;
    FileInputStream sPortIn;
    int os;
    serialComm(String commPort)
    {
	String tempOs = new String( System.getProperty("os.name"));
	if(tempOs.startsWith("Windows")) os=0;
	   else
	   os=1;
	if(os==0)
	    {//Windows

	    }
	else
	    { // Unix Serial Init
		try{
		    sPortIn = new FileInputStream( commPort );
		    sPortOut = new FileOutputStream( commPort );
		}
		catch(Exception e){ System.out.println(e);}
	    }
    }

    public char readChar()
    {
	char tmp;
	tmp=0;
	if(os==0)
	    {//Windows

	    }
	else
	    {//Unix
		try{
		    tmp=(char)sPortIn.read();
		} catch(Exception e){System.out.println(e);}
	    }
	return tmp;
    }

    public char readByte()
    {
	if(os==0)
	    {//Windows
		
	    }
	else
	    { // Unix Serial Init
		try{
		    return((char)sPortIn.read());
		} catch(Exception e){System.out.println(e); }
	    }
	return 0;
    }

    public int aval()
    {	
	if(os==0)
	    {//Windows
		
	    }
	else
	    { // Unix Serial Init
		try{
		    return sPortIn.available();
		} catch(Exception e){System.out.println(e); }
	    }
	return 0;
    }
    
    public void writeStr(String in)
    {	
	if(os==0)
	    {//Windows
		
	    }
	else
	    { // Unix Serial Init
		try{
		    sPortOut.write(in.getBytes());
		} catch(Exception e){System.out.println(e); }	
	    }
    }
}
