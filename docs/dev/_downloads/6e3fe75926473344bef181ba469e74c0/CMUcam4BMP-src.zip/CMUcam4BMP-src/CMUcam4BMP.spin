{{
CMUcam4BMP

Version: 1.0
Date: 1/15/2014

Author: Kwabena W. Agyeman
Copyright: (c) 2014 Kwabena W. Agyeman
All rights reserved - Please see the end of the file for terms of use

Update history:

v1.0 - Original release - 1/15/2014
}}

CON _clkfreq = 96_000_000

CON _clkmode = xtal1 + pll16x

CON RX_PIN = 31

CON TX_PIN = 30

CON BAUD_RATE = 1000000

CON PACKET_SIZE = 1024

CON ' The pin number defined below are for reference only - the code must be changed to move them.

  _CAM_D2_PIN = 0
  _CAM_D3_PIN = 1
  _CAM_D4_PIN = 2
  _CAM_D5_PIN = 3
  _CAM_D6_PIN = 4
  _CAM_D7_PIN = 5
  _CAM_D8_PIN = 6
  _CAM_D9_PIN = 7

  _CAM_D0_PIN = 8
  _CAM_D1_PIN = 9

  _CAM_XCLK_PIN = 10
  _CAM_PCLK_PIN = 11
  _CAM_VSYNC_PIN = 12
  _CAM_HREF_PIN = 13

  _CAM_PWDN_PIN = 14
  _CAM_RESET_PIN = -1

  _SD_CD = 15
  _SD_DO = 16
  _SD_CLK = 17
  _SD_DI = 18
  _SD_CS = 19
  _SD_WP = -1

  _I2C_CLOCK_PIN = 28
  _I2C_DATA_PIN = 29

  _SCCB_CAMERA_WRITE_ADDRESS = $60
  _SCCB_CAMERA_READ_ADDRESS = (_SCCB_CAMERA_WRITE_ADDRESS | $1)

  _CAMERA_PLL_RESET_ADDRESS = $3E
  _CAMERA_PLL_RESET_VALUE = $D0

  _CAMERA_SOFTWARE_RESET_ADDRESS = $12
  _CAMERA_SOFTWARE_RESET_VALUE = $80

  _CAMERA_PLL_RESET_COUNT = 2
  _CAMERA_PLL_RESET_TIMEOUT = 200

  _CAMERA_SCCB_TIMEOUT = 200
  _CAMERA_XCLK_TIMEOUT = 10

  _CAMERA_CLOCK_FREQUENCY = (1 << 31)
  _CAMERA_CLOCK_COUNTER = ((%00100 << 26) + _CAM_XCLK_PIN)

  _DRIVER_HREF_FREQUENCY = 1
  _DRIVER_HREF_COUNTER = %0_01010_000

  _CAMERA_H_RES = 640
  _CAMERA_V_RES = 480

  _CAM_H_DIV = 5
  _CAM_V_DIV = 5

  _CAMERA_H_WIN = (_CAMERA_H_RES / _CAM_H_DIV)
  _CAMERA_V_WIN = (_CAMERA_V_RES / _CAM_V_DIV)

  _CAMERA_MIN_H = 0
  _CAMERA_MAX_H = (_CAMERA_H_WIN - 1)
  _CAMERA_MIN_V = 0
  _CAMERA_MAX_V = (_CAMERA_V_WIN - 1)

VAR long imageBuffer[((_CAMERA_V_WIN * _CAMERA_H_WIN) * 2) / 4]

PUB main

    initCamera

    cognew(@code, @imageBuffer)

    waitpne(0, 0, 0)

DAT code

                        org     0

                        or      outa,               txMask
                        or      dira,               txMask

                        call    #storeImageInit
loop                    call    #storeImage

                        call    #txBegin
                        mov     txOut,              #27
                        call    #txByte
                        mov     txOut,              #_CAMERA_H_WIN
                        call    #txByte
                        mov     txOut,              #_CAMERA_V_WIN
                        call    #txByte
                        call    #txEnd

rxWait0                 call    #rxByte
                        cmp     rxIn,               #13 wz
if_nz                   jmp     #rxWait0

                        mov     parPointer,         par

                        mov     k,                  #((_CAMERA_V_WIN * _CAMERA_H_WIN * 2) / PACKET_SIZE)
txLoop0                 mov     l,                  #(PACKET_SIZE / 4)

                        call    #txBegin
txLoop1                 rdlong  txOut,              parPointer
                        call    #txLong
                        add     parPointer,         #4
                        djnz    l,                  #txLoop1
                        call    #txEnd

rxWait1                 call    #rxByte
                        cmp     rxIn,               #13 wz
if_nz                   jmp     #rxWait1

                        djnz    k,                  #txLoop0

                        jmp     #loop

zero                    long    0

' /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

' ///////////////////// Camera Subroutine /////////////////////////////////////////////////////////////////////////////

storeImageInit          mov     frqa,               #_DRIVER_HREF_FREQUENCY ' Setup counter.
                        movs    ctra,               #_CAM_HREF_PIN          '
                        movi    ctra,               #_DRIVER_HREF_COUNTER   '

storeImageInit_ret      ret

storeImage              mov     parPointer,         par

                        mov     i,                  #_CAMERA_V_WIN          ' Setup main loop counter.

                        waitpeq vsyncMask,          vsyncMask               ' Wait for VSYNC signal.

storeImageLoop0         movd    storeImageLoop1mov, #scanlineBuffer         ' Setup mov loop.
                        mov     j,                  #_CAMERA_H_WIN          '

                        waitpne hrefMask,           hrefMask                ' Wait for the rising HREF edge.
                        mov     phsa,               #0                      '
                        waitpeq hrefMask,           hrefMask                '

                        mov     k,                  #(4 + 7 + 8)            ' Align instructions - can be 18, 19, or 20.
                        add     k,                  cnt                     '
                        waitcnt k,                  #0                      '

storeImageLoop1         mov     k,                  ina                     ' ina[7..0] == 8-bit R5G3 <- Pixel 4 + n
                        mov     l,                  ina                     ' ina[7..0] == 8-bit G3B5
                        shl     k,                  #8                      ' ina[7..0] == 8-bit R5G3 <- Pixel 5 + n
                        and     l,                  #255                    ' ina[7..0] == 8-bit G3B5
                        or      k,                  l                       ' ina[7..0] == 8-bit R5G3 <- Pixel 6 + n
storeImageLoop1mov      mov     scanlineBuffer,     k                       ' ina[7..0] == 8-bit G3B5
                        add     storeImageLoop1mov, destinationInc          ' ina[7..0] == 8-bit R5G3 <- Pixel 7 + n
                        nop                                                 ' ina[7..0] == 8-bit G3B5
                        nop                                                 ' ina[7..0] == 8-bit R5G3 <- Pixel 8 + n
                        djnz    j,                  #storeImageLoop1        ' ina[7..0] == 8-bit G3B5

' /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                        movs    storeImageLoop2mov, #scanlineBuffer
                        mov     j,                  #_CAMERA_H_WIN
storeImageLoop2
storeImageLoop2mov      mov     k,                  scanlineBuffer
                        add     storeImageLoop2mov, #1
                        wrword  k,                  parPointer
                        add     parPointer,         #2
                        djnz    j,                  #storeImageLoop2

' /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                        mov     j,                  #_CAM_V_DIV             ' Sync with frame line.
storeImageLoop3         cmp     j,                  phsa wz, wc             '
if_nz_and_nc            jmp     #storeImageLoop3                            '
                        djnz    i,                  #storeImageLoop0        '

storeImage_ret          ret

hrefMask                long    (|<_CAM_HREF_PIN)
vsyncMask               long    (|<_CAM_VSYNC_PIN)

destinationInc          long    512

' /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

' ///////////////////// RX Subroutine /////////////////////////////////////////////////////////////////////////////////

rxMask                  long    |<RX_PIN

rxLong                  mov     i,                  #4
rxLongLoop0             mov     j,                  #8

                        waitpne rxMask,             rxMask
                        mov     cnt,                cnt
                        add     cnt,                startBitDelay

rxLongLoop1             waitcnt cnt,                dataBitsDelay
                        test    rxMask,             ina wc
                        rcr     rxIn,               #1
                        djnz    j,                  #rxLongLoop1

                        waitcnt cnt,                #0
                        djnz    i,                  #rxLongLoop0
rxLong_ret              ret

rxByte                  mov     i,                  #8

                        waitpne rxMask,             rxMask
                        mov     cnt,                cnt
                        add     cnt,                startBitDelay

rxByteLoop              waitcnt cnt,                dataBitsDelay
                        test    rxMask,             ina wc
                        rcr     rxIn,               #1
                        djnz    i,                  #rxByteLoop

                        waitcnt cnt,                #0
                        shr     rxIn,               #24
rxByte_ret              ret

' /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

' ///////////////////// TX Subroutine /////////////////////////////////////////////////////////////////////////////////

txMask                  long    |<TX_PIN

txBegin                 mov     cnt,                cnt
                        add     cnt,                dataBitsDelay
txBegin_ret             ret

txLong                  mov     i,                  #4
                        shr     txOut,              #1 wc
txLongLoop0             mov     j,                  #8

                        waitcnt cnt,                dataBitsDelay
                        andn    outa,               txMask

txLongLoop1             waitcnt cnt,                dataBitsDelay
                        muxc    outa,               txMask
                        shr     txOut,              #1 wc
                        djnz    j,                  #txLongLoop1

                        waitcnt cnt,                dataBitsDelay
                        or      outa,               txMask
                        djnz    i,                  #txLongLoop0
txLong_ret              ret

txEnd                   waitcnt cnt,                dataBitsDelay
txEnd_ret               ret

txByte                  mov     i,                  #8
                        shr     txOut,              #1 wc

                        waitcnt cnt,                dataBitsDelay
                        andn    outa,               txMask

txByteLoop              waitcnt cnt,                dataBitsDelay
                        muxc    outa,               txMask
                        shr     txOut,              #1 wc
                        djnz    i,                  #txByteLoop

                        waitcnt cnt,                dataBitsDelay
                        or      outa,               txMask
txByte_ret              ret

' /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

' ///////////////////// Serial Data ///////////////////////////////////////////////////////////////////////////////////

startBitDelay           long    _clkfreq / ((BAUD_RATE * 2) / 3) ' 1.5 bit delay
dataBitsDelay           long    _clkfreq / BAUD_RATE ' 1.0 bit delay

' /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

i                       res     1
j                       res     1
k                       res     1
l                       res     1
rxIn                    res     1
txOut                   res     1

parPointer              res     1
scanlineBuffer          res    _CAMERA_H_WIN

                        fit     496

                        byte    "Kwabena W. Agyeman"

CON ' Camera register data structure.

  ' byte0 = camera register write address
  ' byte1 = camera register write value
  ' byte2 = camera register write mask

  ' cr[address] = ((cr[address] & !mask) | (value & mask))

  _CR_LENGTH = 3

  _CR_ADDRESS = 0
  _CR_VALUE = 1
  _CR_MASK = 2

PUB initCamera '' Turn the camera module on. Return true on success and false on failure.

  frqa := _CAMERA_CLOCK_FREQUENCY
  ctra := _CAMERA_CLOCK_COUNTER

  outa[_CAM_XCLK_PIN] := 0
  dira[_CAM_XCLK_PIN] := 1

  dira[_CAM_PWDN_PIN] := outa[_CAM_PWDN_PIN] := 0
  waitcnt((clkfreq / _CAMERA_XCLK_TIMEOUT) + cnt)

  repeat _CAMERA_PLL_RESET_COUNT
    ifnot(SCCBWriteRegister(_CAMERA_PLL_RESET_ADDRESS, _CAMERA_PLL_RESET_VALUE))
      return false

    waitcnt((clkfreq / _CAMERA_PLL_RESET_TIMEOUT) + cnt)

  if(SCCBWriteRegister(_CAMERA_SOFTWARE_RESET_ADDRESS, _CAMERA_SOFTWARE_RESET_VALUE))
    waitcnt((clkfreq / _CAMERA_SCCB_TIMEOUT) + cnt)

    repeat result from 0 to constant((_CAMERA_INIT_NUMBER - 1) * (_CR_LENGTH - 1)) step (_CR_LENGTH - 1)
      ifnot(SCCBWriteRegister(Camera_Init_Data[result + _CR_ADDRESS], Camera_Init_Data[result + _CR_VALUE]))
        return false

    return SCCBCameraControl(@Camera_Setup_Data, CAMERA_SETUP_NUMBER)

CON _CAMERA_INIT_NUMBER = 129 ' See OmniVision OV9665 implementation guide and data sheet for more details.

DAT Camera_Init_Data ' 129 Registers

' Format - register, data

byte $D5, $FF
byte $D6, $3F
byte $3D, $3C
byte $11, $80
byte $2A, $00
byte $2B, $00
byte $3A, $D9
byte $3B, $00
byte $3C, $58
byte $3E, $D0
byte $71, $00
byte $15, $00
byte $D7, $10
byte $6A, $24
byte $85, $E7
byte $63, $00
byte $12, $40
byte $4D, $09
byte $17, $0C
byte $18, $5C
byte $19, $02
byte $1A, $3F
byte $03, $03
byte $32, $90
byte $2B, $00
byte $5C, $80
byte $36, $B4
byte $65, $10
byte $70, $02
byte $71, $9F
byte $64, $A4
byte $5C, $80
byte $43, $00
byte $5D, $55
byte $5E, $57
byte $5F, $21
byte $24, $3E
byte $25, $38
byte $26, $72
byte $14, $68
byte $0C, $38
byte $4F, $4F
byte $50, $42
byte $5A, $67
byte $7D, $30
byte $7E, $00
byte $82, $03
byte $7F, $00
byte $83, $07
byte $80, $03
byte $81, $04
byte $96, $F0
byte $97, $00
byte $92, $33
byte $94, $5A
byte $93, $3A
byte $95, $48
byte $91, $FC
byte $90, $FF
byte $8E, $4E
byte $8F, $4E
byte $8D, $13
byte $8C, $0C
byte $8B, $0C
byte $86, $9E
byte $87, $11
byte $88, $22
byte $89, $05
byte $8A, $03
byte $9B, $0E
byte $9C, $1C
byte $9D, $34
byte $9E, $5A
byte $9F, $68
byte $A0, $76
byte $A1, $82
byte $A2, $8E
byte $A3, $98
byte $A4, $A0
byte $A5, $B0
byte $A6, $BE
byte $A7, $D2
byte $A8, $E2
byte $A9, $EE
byte $AA, $18
byte $AB, $E7
byte $B0, $43
byte $AC, $04
byte $84, $40
byte $AD, $82
byte $D9, $11
byte $DA, $00
byte $AE, $10
byte $AB, $E7
byte $B9, $50
byte $BA, $3C
byte $BB, $50
byte $BC, $3C
byte $BD, $08
byte $BE, $19
byte $BF, $02
byte $C0, $08
byte $C1, $2A
byte $C2, $34
byte $C3, $2D
byte $C4, $2D
byte $C5, $00
byte $C6, $98
byte $C7, $18
byte $69, $48
byte $74, $C0
byte $7C, $28
byte $65, $11
byte $66, $00
byte $41, $C0
byte $5B, $24
byte $60, $82
byte $05, $07
byte $03, $03
byte $D2, $94
byte $C8, $06
byte $CB, $40
byte $CC, $40
byte $CF, $00
byte $D0, $20
byte $D1, $00
byte $C7, $18
byte $0D, $92
byte $0D, $90

CON CAMERA_SETUP_NUMBER = 3 ' See OmniVision OV9665 implementation guide and data sheet for more details.

DAT Camera_Setup_Data ' 3 Registers

' Format - register, data, mux mask

byte $6A, $14, $FF
byte $D8, $C1, $C7
byte $D7, $01, $13

PUB finiCamera '' Turn the camera module off. Return true on success and false on failure.

  if(SCCBCameraControl(@Camera_Fini_Data, _CAMERA_FINI_NUMBER))
    dira[_CAM_PWDN_PIN] := outa[_CAM_PWDN_PIN] := 1
    dira[_CAM_XCLK_PIN] := ctra := phsa := frqa := 0
    return true

CON _CAMERA_FINI_NUMBER = 4 ' See OmniVision OV9665 implementation guide and data sheet for more details.

DAT Camera_Fini_Data ' 4 Registers

' Format - register, data, mux mask

byte $3B, $00, $08
byte $39, $6A, $FF
byte $D5, $00, $FF
byte $D6, $00, $FF

PUB AGCSetting(onOrOff) '' Change auto gain control. Return true on success and false on failure.

  AGC_Switch_Data[_CR_VALUE] := (onOrOff <> false)
  return SCCBCameraControl(@AGC_Switch_Data, _AGC_SWITCH_NUMBER)

CON _AGC_SWITCH_NUMBER = 1 ' See OmniVision OV9665 implementation guide and data sheet for more details.

DAT AGC_Switch_Data ' 1 Register

' Format - register, data, mux mask

byte $13, $00, $04

PUB AWBSetting(onOrOff) '' Change auto white balance control. Return true on success and false on failure.

  AWB_Switch_Data[_CR_VALUE] := (onOrOff <> false)
  return SCCBCameraControl(@AWB_Switch_Data, _AWB_SWITCH_NUMBER)

CON _AWB_SWITCH_NUMBER = 1 ' See OmniVision OV9665 implementation guide and data sheet for more details.

DAT AWB_Switch_Data ' 1 Register

' Format - register, data, mux mask

byte $13, $00, $02

PUB brightnessSetting(brightness) '' Change brightness settings (-128 to 127). Return true on success and false on failure.

  Brightness_Switch_Data[_CR_VALUE] := ((||brightness) & $7F)
  Brightness_Switch_Data[_BRIGHTNESS_NEGATIVE_CR_VALUE] := (_BRIGHTNESS_DEFAULT | ((brightness < 0) & _BRIGHTNESS_NEGATIVE))
  return SCCBCameraControl(@Brightness_Switch_Data, _BRIGHTNESS_SWITCH_NUMBER)

CON _BRIGHTNESS_SWITCH_NUMBER = 3 ' See OmniVision OV9665 implementation guide and data sheet for more details.

  _BRIGHTNESS_DEFAULT = $10
  _BRIGHTNESS_NEGATIVE = $8
  _BRIGHTNESS_NEGATIVE_CR_VALUE = (_CR_VALUE + (_CR_LENGTH * 2))

DAT Brightness_Switch_Data ' 3 Registers

' Format - register, data, mux mask

byte $D1, $00, $FF
byte $C8, $04, $04
byte $C7, $00, $18

PUB contrastSetting(contrast) '' Change constrast settings (-32 to 31). Return true on success and false on failure.

  Contrast_Switch_Data[_CR_VALUE] := ((contrast // constant(_CONTRAST_MAXIMUM - _CONTRAST_MINIMUM + 1)) + _CONTRAST_DEFAULT)
  return SCCBCameraControl(@Contrast_Switch_Data, _CONTRAST_SWITCH_NUMBER)

CON _CONTRAST_SWITCH_NUMBER = 4 ' See OmniVision OV9665 implementation guide and data sheet for more details.

  _CONTRAST_DEFAULT = $20
  _CONTRAST_MAXIMUM = $1F
  _CONTRAST_MINIMUM = $0

DAT Contrast_Switch_Data ' 4 Registers

' Format - register, data, mux mask

byte $D0, $00, $FF
byte $64, $02, $02
byte $C8, $04, $04
byte $C7, $34, $34

PUB verticalFlipSetting(onOrOff) '' Change vertical flip settings. Return true on success and false on failure.

  Vertical_Flip_Data[_CR_VALUE] := (onOrOff <> false)
  return SCCBCameraControl(@Vertical_Flip_Data, _VERTICAL_FLIP_NUMBER)

CON _VERTICAL_FLIP_NUMBER = 1 ' See OmniVision OV9665 implementation guide and data sheet for more details.

DAT Vertical_Flip_Data ' 1 Register

' Format - register, data, mux mask

byte $04, $00, $40

PUB horizontalMirrorSetting(onOrOff) '' Change horizontal mirror settings. Return true on success and false on failure.

  Horizontal_Mirror_Data[_CR_VALUE] := (onOrOff <> false)
  return SCCBCameraControl(@Horizontal_Mirror_Data, _HORIZONTAL_MIRROR_NUMBER)

CON _HORIZONTAL_MIRROR_NUMBER = 2 ' See OmniVision OV9665 implementation guide and data sheet for more details.

DAT Horizontal_Mirror_Data ' 2 Registers

' Format - register, data, mux mask

byte $33, $00, $08
byte $04, $80, $80

PRI SCCBCameraControl(address, length) | index, temp ' Updates camera controls from data structures.

' Notes:
'
' Address - The address of the data structure.
' Length - The length of the data structure.
'
' Returns false on success and false on failure.

  length := ((length - 1) * _CR_LENGTH)

  repeat index from 0 to length step _CR_LENGTH

    ifnot(SCCBReadRegister(byte[address][index + _CR_ADDRESS], @temp))
      return false

    ifnot(SCCBWriteRegister( byte[address][index + _CR_ADDRESS], {
                           } ( (temp & (!byte[address][index + _CR_MASK])) | {
                           }   (byte[address][index + _CR_VALUE] & byte[address][index + _CR_MASK]) ) ) )
      return false

  return true

PRI SCCBWriteRegister(register, data) ' Writes a camera register.

' Notes:
'
' Register - The register number to write.
' Data - The value to write.
'
' Returns true on success and false on failure.

  I2CStart
  result := I2CWrite(_SCCB_CAMERA_WRITE_ADDRESS)
  result and= I2CWrite(register)
  result and= I2CWrite(data)
  I2CStop

PRI SCCBReadRegister(register, longDataAddress) ' Reads a camera register.

' Notes:
'
' Register - The register number to read.
' LongDataAddress - The address of the value to store data to.
'
' Returns true on success and false on failure.

  I2CStart
  result := I2CWrite(_SCCB_CAMERA_WRITE_ADDRESS)
  result and= I2CWrite(register)
  I2CStop

  if(result)
    I2CStart
    result := I2CWrite(_SCCB_CAMERA_READ_ADDRESS)
    long[longDataAddress] := I2CRead(false)
    I2CStop

PRI I2CWrite(data) ' Write out data.

' Notes:
'
' Data - The 8 bit packet to transmit.
'
' Returns true if the receiving device ACK'ed and false if not.

  data := ((!data) >< 8)

  repeat 8 ' Write out all 8 data bits. Leave with clock low.
    dira[_I2C_DATA_PIN] := data
    dira[_I2C_CLOCK_PIN] := 0
    dira[_I2C_CLOCK_PIN] := 1
    data >>= 1

  ' Leave with clock low and data low.

  dira[_I2C_DATA_PIN] := 0
  dira[_I2C_CLOCK_PIN] := 0
  result := not(ina[_I2C_DATA_PIN])
  dira[_I2C_CLOCK_PIN] := 1
  dira[_I2C_DATA_PIN] := 1

PRI I2CRead(aknowledge) ' Read in data.

' Notes:
'
' Aknowledge - True to send the transmitting device an ACK and false to not send a NCK.
'
' Returns the received 8 bit packet.

  dira[_I2C_DATA_PIN] := 0

  repeat 8 ' Read in all 8 data bits. Leave with clock low.
    result <<= 1
    dira[_I2C_CLOCK_PIN] := 0
    result |= ina[_I2C_DATA_PIN]
    dira[_I2C_CLOCK_PIN] := 1

  ' Leave with the clock low and the data low.

  dira[_I2C_DATA_PIN] := (not(not(aknowledge)))
  dira[_I2C_CLOCK_PIN] := 0
  dira[_I2C_CLOCK_PIN] := 1
  dira[_I2C_DATA_PIN] := 1

PRI I2CStart ' Cause the I2C start condition.

  outa[_I2C_DATA_PIN] := 0
  dira[_I2C_DATA_PIN] := 1
  outa[_I2C_CLOCK_PIN] := 0
  dira[_I2C_CLOCK_PIN] := 1

PRI I2CStop ' Cause the I2C stop condition.

  dira[_I2C_CLOCK_PIN] := 0
  dira[_I2C_DATA_PIN] := 0

{{
MIT License - TERMS OF USE:

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
}}