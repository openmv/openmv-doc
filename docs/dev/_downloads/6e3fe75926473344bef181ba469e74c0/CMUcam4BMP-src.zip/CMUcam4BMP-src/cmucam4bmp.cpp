/***************************************************************************//**
* @file
* CMUcam4BMP
*
* @version @n 1.0
* @date @n 1/15/2014
*
* @author @n Kwabena W. Agyeman
* @copyright @n (c) 2014 Kwabena W. Agyeman
* @n All rights reserved - Please see the end of the file for the terms of use
*
* @par Update History:
* @n v1.0 - Original release - 1/15/2014
*******************************************************************************/

#include "cmucam4bmp.h"
#include "ui_cmucam4bmp.h"

CMUcam4BMP::CMUcam4BMP(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::CMUcam4BMP)
{
    ui->setupUi(this);

    QPixmap pixmap(1, 1); pixmap.fill(Qt::white);
    ui->pixmap->setPixmap(pixmap);

    connect(ui->actionExit, SIGNAL(triggered()),
            this, SLOT(close()));

    connect(ui->actionSave, SIGNAL(triggered()),
            this, SLOT(save()));

    QStringList stringList;

    foreach(QSerialPortInfo port, QSerialPortInfo::availablePorts())
    {
        stringList.append(port.portName());
    }

    if(!stringList.isEmpty())
    {
        bool ok; QString string = QInputDialog::getItem(this, windowTitle(),
        tr("Please select a serial port"), stringList, 0, false, &ok,
        Qt::MSWindowsFixedSizeDialogHint | Qt::WindowTitleHint |
        Qt::WindowSystemMenuHint | Qt::WindowCloseButtonHint);

        if(ok)
        {
            m_serialPort = new QSerialPort(string, this); m_state = PREAMBLE;

            if(m_serialPort->open(QIODevice::ReadWrite)
            && m_serialPort->setBaudRate(BAUD_RATE)
            && m_serialPort->setDataBits(QSerialPort::Data8)
            && m_serialPort->setDataTerminalReady(true)
            && m_serialPort->setFlowControl(QSerialPort::NoFlowControl)
            && m_serialPort->setParity(QSerialPort::NoParity)
            && m_serialPort->setRequestToSend(true)
            && m_serialPort->setStopBits(QSerialPort::OneStop))
            {
                QThread::msleep(100);

                if(m_serialPort->setDataTerminalReady(false)
                && m_serialPort->setRequestToSend(false))
                {
                    QThread::msleep(100);

                    if(m_serialPort->clear())
                    {
                        connect(m_serialPort, SIGNAL(readyRead()),
                                this, SLOT(readyRead()));

                        show(); return;
                    }
                }
            }

            QMessageBox::critical(this, windowTitle(),
                                  tr("Open serial port failed"));
        }
    }
    else
    {
        QMessageBox::critical(this, windowTitle(),
                              tr("No serial ports found"));
    }

    QTimer::singleShot(0, this, SLOT(close()));
}

CMUcam4BMP::~CMUcam4BMP()
{
    delete ui;
}

void CMUcam4BMP::readyRead()
{
    QByteArray data = m_serialPort->readAll();

    for(int i = 0, j = data.size(); i < j; i++)
    {
        switch(m_state)
        {
            case PREAMBLE:
            {
                if(data.at(i) == '\e')
                {
                    m_state = XSIZE;
                }

                break;
            }

            case XSIZE:
            {
                m_xSize = static_cast<uchar>(data.at(i)); m_state = YSIZE;

                break;
            }

            case YSIZE:
            {
                m_ySize = static_cast<uchar>(data.at(i)); m_state = PIXMAP;

                m_size = m_xSize * m_ySize * 2; m_data.clear();

                if(m_size == 0)
                {
                    m_state = PREAMBLE;

                    QPixmap pixmap(1, 1); pixmap.fill(Qt::white);
                    ui->pixmap->setPixmap(pixmap);
                }

                m_serialPort->putChar('\r');

                break;
            }

            case PIXMAP:
            {
                if(m_size--)
                {
                    m_data.append(data.at(i));

                    if((!m_size) || (!(m_data.size() % PACKET_SIZE)))
                    {
                        m_serialPort->putChar('\r');
                    }
                }

                if(!m_size)
                {
                    m_state = PREAMBLE;

                    QImage image(reinterpret_cast<uchar *>(m_data.data()),
                    m_xSize, m_ySize, m_xSize * 2, QImage::Format_RGB16);

                    ui->pixmap->setPixmap(QPixmap::fromImage(image));
                }

                break;
            }
        }
    }
}

void CMUcam4BMP::save()
{
    QString string = QFileDialog::getSaveFileName(this, windowTitle(),
                                                  QDir::homePath());

    if(!string.isEmpty())
    {
        if(!ui->pixmap->pixmap()->save(string))
        {
            QMessageBox::critical(this, windowTitle(),
                                  tr("Save Image Failed"));
        }
    }
}

/***************************************************************************//**
* @file
* @par MIT License - TERMS OF USE:
* @n Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Software"), to
* deal in the Software without restriction, including without limitation the
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
* sell copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* @n
* @n The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
* @n
* @n THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*******************************************************************************/
