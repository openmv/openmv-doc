/***************************************************************************//**
* @file
* CMUcam4BMP
*
* @version @n 1.0
* @date @n 1/15/2014
*
* @author @n Kwabena W. Agyeman
* @copyright @n (c) 2014 Kwabena W. Agyeman
* @n All rights reserved - Please see the end of the file for the terms of use
*
* @par Update History:
* @n v1.0 - Original release - 1/15/2014
*******************************************************************************/

#ifndef CMUCAM4BMP_H
#define CMUCAM4BMP_H

#include <QtCore>
#include <QtGui>
#include <QtSerialPort>
#include <QtWidgets>

#define BAUD_RATE 1000000

#define PACKET_SIZE 1024

namespace Ui
{
    class CMUcam4BMP;
}

class CMUcam4BMP : public QMainWindow
{
    Q_OBJECT

public:

    explicit CMUcam4BMP(QWidget *parent = NULL);
    ~CMUcam4BMP();

private slots:

    void readyRead();

    void save();

private:

    Q_DISABLE_COPY(CMUcam4BMP)

    QSerialPort *m_serialPort;

    enum { PREAMBLE, XSIZE, YSIZE, PIXMAP } m_state;

    int m_xSize, m_ySize, m_size; QByteArray m_data;

    Ui::CMUcam4BMP *ui;
};

#endif // CMUCAM4BMP_H

/***************************************************************************//**
* @file
* @par MIT License - TERMS OF USE:
* @n Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Software"), to
* deal in the Software without restriction, including without limitation the
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
* sell copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* @n
* @n The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
* @n
* @n THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*******************************************************************************/
