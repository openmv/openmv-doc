/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * This file is part of CMUcamGUI, a java program that helps     *
 * interface with the CMUcam Vision Board.                       *
 * Contact cmucam@cs.cmu.edu, or see                             *
 * http://www.cs.cmu.edu/~cmucam for more information.           *
 *                                                               *
 * Copyright 2001 Anthony Rowe                                   *
 *                                                               *
 * This program is free software; you can redistribute it and/or *
 * modify it under the terms of the GNU General Public License   *
 * as published by the Free Software Foundation - version 2.     *
 *                                                               *
 * This program is distributed in the hope that it will be       *
 * useful, but WITHOUT ANY WARRANTY; without even the implied    *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR       *
 * PURPOSE.  See the GNU General Public License in file COPYING  *
 * for more details.                                             *
 *                                                               *
 * You should have received a copy of the GNU General Public     *
 * License along with this program; if not, write to the Free    *
 * Software Foundation, Inc., 59 Temple Place - Suite 330,       *
 * Boston, MA 02111, USA.                                        *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.*;
import java.lang.Object;
import java.util.*;


public class outWindow extends Canvas
{
Frame out_f;
Panel out_p;
TextArea out_t;
int count;

    outWindow()
    {
	out_f= new Frame("Output Window");
	Panel out_p = new Panel();
	out_f.setBackground(Color.lightGray);
	out_t=new TextArea("");
	out_f.add(out_t);
	out_f.setSize(400,300);
	out_f.setLocation(260,250);
	out_f.show();
	int count=0;
    }
   
    public void append(String data)
    {
	out_t.append( data + "\n");
	count++;
	if(count>1000)
	{
	 out_t.setText( data + "\n");
	count=0;
	}

    }


}
