This program detects during run time which OS it is running and switches to 
the appropriate serial port drivers. It can run under Unix systems that can 
read and write to the serial port as if it where a file and windows 95/98/2000.

To compile the CMUcamGUI demo program, ensure that you have a java development 
environment installed that allows you to use the "java" command ("javac" if 
you wish to recompile). CMUcamGUI requires java v1.2.2 or higher.

To compile the java files, cd into their directory and type
>javac *.java

To execute the java program type
>java CMUcamGUI



*Notes about CMUcamGUI:
In this early release, many of the scaling features of the CMUcam cause
problems.  At 17 fps, 115,200 baud things perform as they should.  At lower 
baud rates and slower frame rates commands like bitmap mode may start to fail,
due to the longer or shorter serial transfer window.  In many of the more 
advanced modes, CMUcam will scale output data based on these factors.  The 
java GUI assumes 17 fps at 115,200 baud. These problems will be fixed in later
releases. 

