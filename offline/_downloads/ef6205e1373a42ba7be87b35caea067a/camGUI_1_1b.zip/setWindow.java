/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * This file is part of CMUcamGUI, a java program that helps     *
 * interface with the CMUcam Vision Board.                       *
 * Contact cmucam@cs.cmu.edu, or see                             *
 * http://www.cs.cmu.edu/~cmucam for more information.           *
 *                                                               *
 * Copyright 2001 Anthony Rowe                                   *
 *                                                               *
 * This program is free software; you can redistribute it and/or *
 * modify it under the terms of the GNU General Public License   *
 * as published by the Free Software Foundation - version 2.     *
 *                                                               *
 * This program is distributed in the hope that it will be       *
 * useful, but WITHOUT ANY WARRANTY; without even the implied    *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR       *
 * PURPOSE.  See the GNU General Public License in file COPYING  *
 * for more details.                                             *
 *                                                               *
 * You should have received a copy of the GNU General Public     *
 * License along with this program; if not, write to the Free    *
 * Software Foundation, Inc., 59 Temple Place - Suite 330,       *
 * Boston, MA 02111, USA.                                        *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.*;
import java.lang.Object;
import java.util.*;


public class setWindow extends Canvas
{
    Frame setWindow_f;
    Panel setWindow_p;
    TextField x1_t,y1_t,x2_t,y2_t;
    int x1,x2,y1,y2;


    setWindow()
    {
	setWindow_f= new Frame("Window Size");
	Panel setWindow_p = new Panel();
	setWindow_f.setBackground(Color.lightGray);
	setWindow_f.setLayout(new GridLayout(2,3));
	x1_t=new TextField("1");
	y1_t=new TextField("1");
	x1=1;
	y1=1;
	x2_t=new TextField("80");
	y2_t=new TextField("143");
	setWindow_f.add(new Label("Upper Left (x,y)"));
	setWindow_f.add(x1_t);
	setWindow_f.add(y1_t);
	setWindow_f.add(new Label("Lower Right(x2,y2)"));
	setWindow_f.add(x2_t);
	setWindow_f.add(y2_t);
	setWindow_f.setSize(300,80);
	setWindow_f.setLocation(0,590);
	setWindow_f.show();
	
    }
    public void hide() { setWindow_f.hide(); }
    public void show() { setWindow_f.show(); }

    public String sendString()
    {
	x1=(new Integer(x1_t.getText())).intValue();
	y1=(new Integer(y1_t.getText())).intValue();

	return("SW " +x1_t.getText()+" "+y1_t.getText()+" "+x2_t.getText()
	         + " " +y2_t.getText()+ "\r" );


    }
    
    public int rX(){ return x1; }
    public int rY(){ return y1; }

}
