You now have the CMUcam firmware this is the software that gives the CMUcam vision boards its functionality.  
To download it to the camera you need an SX-Key/Blitzer or compatible downloader.

The SX-Key downloader software and manual are available at:  
www.parallaxinc.com/html_files/downloads/downloads_sx.htm 

Downloading The Firmware 
 
After downloading and installing the SX-Key software, it is necessary to load the CMUcam.hex firmware 
to the board. 

step 1:   Turn on the board's power. 
step 2:   Ensure that the programming switch is in the program mode (pushed away from the regulator) 
step 3:   Plug in the SX-key text side facing away from the board. 
          (for more details see the hardware port section of the manual) 
step 4:   Open up the SX-Key software 
step 5:   Select "Device" from under the "Run" menu 
step 6:   Click on the "Load Hex" button 
step 7:   Go to the directory of the CMUcam.hex file and type its name into the dialog box. 
          (It may not be visible) 
step 8:   Press "Open" to load it 
step 9:   Press the "Program" button 
step 10:  Once programming has finished, turn off the power to the board 
step 11:  Unplug the SX-Key and switch the programming switch into the run position 
step 12:  Once the power switch is turned on again the firmware should be running and will greet you with 

For more information see the CMUcam User Manual or go to http://www.cs.cmu.edu/~cmucam




CMUcam.hex Copyright 2001 Chuck Rosenberg, Anthony Rowe under the GNU General Public License   